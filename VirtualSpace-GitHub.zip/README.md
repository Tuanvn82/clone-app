# VirtualSpace

A GitHub-ready Android foundation for a Dual Space / Virtual Master-style application.

## What is included

- Modern Kotlin + Jetpack Compose UI
- Virtual profile model
- Local profile persistence
- Safe mock virtual-root provider
- Virtual path validation
- Unit tests
- Clean separation between UI, data and virtualization interfaces
- No host root modification
- No hidden Android APIs
- No arbitrary shell execution

## Important limitation

A normal third-party Android application cannot transparently execute an arbitrary installed APK
as a second Android installation using only public Android APIs.

This repository therefore provides a real, buildable foundation and a `VirtualizationBackend`
boundary for a future legitimate virtualization implementation. The current Mock Virtual Root is
internal simulation only.

It must NOT be presented as real device root or as a mechanism to bypass Play Integrity, SELinux,
Verified Boot, DRM, banking-app security or other Android security controls.

## Build

Requirements:

- Android Studio 2026.1.x or compatible
- JDK 17
- Android SDK 37
- Gradle 9.5
- Android Gradle Plugin 9.3.0

Open the repository in Android Studio and sync Gradle.

Command line:

```bash
./gradlew assembleDebug
./gradlew test
```

## GitHub

Upload the contents of this folder to a new repository. Do not commit `local.properties`,
`.idea/`, build outputs, or signing keys.

## Roadmap

1. Add real installed-app discovery.
2. Add profile editor and lifecycle state.
3. Add isolated virtual filesystem UI.
4. Add Storage Access Framework backup/restore.
5. Implement and test a legitimate virtualization backend separately.
