# Architecture

UI -> ViewModel/State -> Repository -> Local storage

Virtualization is isolated behind a backend interface so unsupported Android internals do not leak
into the UI.

The MockVirtualRootProvider intentionally uses no shell, no `su`, no hidden API and no host-file
access.
