# Virtual Root

Virtual Root is an internal simulation.

`uid=0` and `gid=0` in this project are virtual values only. They do not represent Linux kernel
credentials and do not grant root privileges on the Android device.

Allowed mock commands are interpreted by Kotlin code. They are never passed to `Runtime.exec`,
`ProcessBuilder`, `su`, or a shell.
