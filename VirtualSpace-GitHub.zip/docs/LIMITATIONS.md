# Limitations

The current build does not claim to virtualize arbitrary third-party APK execution.

A production virtualization backend requires platform-specific engineering and device-level testing.
It must also respect Android security boundaries and application licensing.
