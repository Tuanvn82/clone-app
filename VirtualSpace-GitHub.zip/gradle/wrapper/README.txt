Run `gradle wrapper --gradle-version 9.5` once if gradle-wrapper.jar is not supplied by your IDE.
