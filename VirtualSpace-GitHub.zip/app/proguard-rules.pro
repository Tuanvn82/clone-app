# VirtualSpace intentionally keeps release shrinking disabled initially.
# Add narrowly scoped rules only after release testing.
