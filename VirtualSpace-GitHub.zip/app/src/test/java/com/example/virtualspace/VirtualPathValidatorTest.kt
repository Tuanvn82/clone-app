package com.example.virtualspace

import com.example.virtualspace.domain.VirtualPathValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VirtualPathValidatorTest {
    @Test fun normalPathAccepted() {
        assertTrue(VirtualPathValidator.validate("/data/app/file.txt"))
    }

    @Test fun traversalRejected() {
        assertFalse(VirtualPathValidator.validate("../../host-secret"))
    }

    @Test fun nullByteRejected() {
        assertFalse(VirtualPathValidator.validate("/data/\u0000evil"))
    }
}
