package com.example.virtualspace

import com.example.virtualspace.data.VirtualProfile
import com.example.virtualspace.domain.MockVirtualRootProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VirtualRootProviderTest {
    private val provider = MockVirtualRootProvider()
    private val profile = VirtualProfile(
        packageName = "example",
        label = "Example",
        virtualRootEnabled = true,
        virtualUid = 0,
        virtualGid = 0
    )

    @Test fun idIsVirtual() {
        val result = provider.executeVirtualCommand(profile, "id", emptyList())
        assertTrue(result.ok)
        assertEquals("uid=0 gid=0", result.output)
    }

    @Test fun arbitraryCommandIsRejected() {
        val result = provider.executeVirtualCommand(profile, "su", emptyList())
        assertFalse(result.ok)
    }

    @Test fun disabledRootRejectsCommands() {
        val disabled = profile.copy(virtualRootEnabled = false)
        val result = provider.executeVirtualCommand(disabled, "id", emptyList())
        assertFalse(result.ok)
    }
}
