package com.example.virtualspace.domain

import java.nio.file.Path
import java.nio.file.Paths

object VirtualPathValidator {
    fun validate(path: String): Boolean {
        if (path.isBlank() || path.length > 512) return false
        if (path.contains('\u0000')) return false
        val normalized = runCatching {
            Paths.get("/virtual").resolve(path.removePrefix("/")).normalize()
        }.getOrNull() ?: return false
        return normalized.startsWith(Path.of("/virtual"))
    }
}
