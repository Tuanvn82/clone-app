package com.example.virtualspace.domain

import com.example.virtualspace.data.VirtualProfile

data class VirtualResult(
    val ok: Boolean,
    val output: String,
    val error: String? = null
)

interface VirtualRootProvider {
    fun isEnabled(profile: VirtualProfile): Boolean
    fun getUid(profile: VirtualProfile): Int
    fun getGid(profile: VirtualProfile): Int
    fun hasCapability(profile: VirtualProfile, capability: String): Boolean
    fun executeVirtualCommand(profile: VirtualProfile, command: String, args: List<String>): VirtualResult
}

class MockVirtualRootProvider : VirtualRootProvider {
    private val allowed = setOf("id", "whoami", "getprop", "mount", "uname", "pwd", "ls", "cat")

    override fun isEnabled(profile: VirtualProfile) = profile.virtualRootEnabled
    override fun getUid(profile: VirtualProfile) = profile.virtualUid
    override fun getGid(profile: VirtualProfile) = profile.virtualGid

    override fun hasCapability(profile: VirtualProfile, capability: String): Boolean =
        profile.virtualRootEnabled && capability in setOf("VIRTUAL_FILESYSTEM", "MOCK_COMMANDS")

    override fun executeVirtualCommand(
        profile: VirtualProfile,
        command: String,
        args: List<String>
    ): VirtualResult {
        if (!profile.virtualRootEnabled) {
            return VirtualResult(false, "", "Virtual Root is disabled.")
        }
        if (command !in allowed) {
            return VirtualResult(false, "", "Command is not available in Mock Virtual Root.")
        }

        return when (command) {
            "id" -> VirtualResult(true, "uid=${profile.virtualUid} gid=${profile.virtualGid}")
            "whoami" -> VirtualResult(true, if (profile.virtualUid == 0) "root" else "virtual-user")
            "getprop" -> VirtualResult(true, "ro.virtualspace.root=mock\nro.virtualspace.profile=${profile.id}")
            "mount" -> VirtualResult(true, "virtualfs on / type virtual (internal mock)")
            "uname" -> VirtualResult(true, "VirtualSpace-Kernel virtual")
            "pwd" -> VirtualResult(true, "/")
            "ls" -> VirtualResult(true, "data\nproc\nsystem\ntmp")
            "cat" -> {
                if (args.singleOrNull() == "/proc/version") {
                    VirtualResult(true, "VirtualSpace Mock Kernel")
                } else {
                    VirtualResult(false, "", "Only virtual files can be read.")
                }
            }
            else -> VirtualResult(false, "", "Unsupported command.")
        }
    }
}
