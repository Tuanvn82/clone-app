package com.example.virtualspace.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.virtualspace.data.VirtualProfile
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualSpaceApp() {
    var profiles by remember { mutableStateOf(listOf<VirtualProfile>()) }
    var showSettings by remember { mutableStateOf(false) }

    if (showSettings) {
        SettingsScreen(onBack = { showSettings = false })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Virtual Space") },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    profiles = profiles + VirtualProfile(
                        id = UUID.randomUUID().toString(),
                        packageName = "example.app",
                        label = "Demo App"
                    )
                }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add App")
            }
        }
    ) { padding ->
        if (profiles.isEmpty()) {
            EmptyState(padding)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    ProfileCard(profile)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(padding: PaddingValues) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Chưa có ứng dụng ảo", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Nhấn + để tạo profile. Đây là bản nền tảng an toàn; backend virtualize APK thật chưa được giả mạo.",
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun ProfileCard(profile: VirtualProfile) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(profile.label, style = MaterialTheme.typography.titleMedium)
            Text(profile.packageName, style = MaterialTheme.typography.bodySmall)
            Row(modifier = Modifier.padding(top = 12.dp)) {
                Icon(Icons.Default.Security, contentDescription = null)
                Text(
                    if (profile.virtualRootEnabled) " Mock Root ON" else " Mock Root OFF",
                    modifier = Modifier.padding(start = 6.dp)
                )
            }
            Button(
                onClick = {},
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) {
                Text("Mở profile")
            }
        }
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Virtual Root ở đây chỉ là root mô phỏng nội bộ. Nó không cấp quyền root thật cho Android.",
            modifier = Modifier.padding(top = 12.dp)
        )
        Button(onClick = onBack, modifier = Modifier.padding(top = 24.dp)) {
            Text("Quay lại")
        }
    }
}
