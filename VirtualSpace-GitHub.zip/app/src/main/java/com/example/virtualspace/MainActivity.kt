package com.example.virtualspace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.virtualspace.ui.VirtualSpaceApp
import com.example.virtualspace.ui.theme.VirtualSpaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VirtualSpaceTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VirtualSpaceApp()
                }
            }
        }
    }
}
