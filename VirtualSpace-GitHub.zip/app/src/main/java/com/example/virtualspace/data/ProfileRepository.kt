package com.example.virtualspace.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ProfileRepository(private val context: Context) {
    private val file: File
        get() = File(context.filesDir, "profiles.json")

    suspend fun load(): List<VirtualProfile> = withContext(Dispatchers.IO) {
        if (!file.exists()) return@withContext emptyList()
        runCatching {
            val array = JSONArray(file.readText())
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        VirtualProfile(
                            id = o.getString("id"),
                            packageName = o.getString("packageName"),
                            label = o.getString("label"),
                            virtualRootEnabled = o.optBoolean("virtualRootEnabled"),
                            virtualUid = o.optInt("virtualUid", 0),
                            virtualGid = o.optInt("virtualGid", 0),
                            devicePreset = o.optString("devicePreset", "DEFAULT"),
                            networkMode = o.optString("networkMode", "HOST"),
                            createdAt = o.optLong("createdAt"),
                            lastUsedAt = o.optLong("lastUsedAt")
                        )
                    )
                }
            }
        }.getOrElse { emptyList() }
    }

    suspend fun save(profiles: List<VirtualProfile>) = withContext(Dispatchers.IO) {
        val temp = File(context.filesDir, "profiles.json.tmp")
        val array = JSONArray()
        profiles.forEach { p ->
            array.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("packageName", p.packageName)
                    put("label", p.label)
                    put("virtualRootEnabled", p.virtualRootEnabled)
                    put("virtualUid", p.virtualUid)
                    put("virtualGid", p.virtualGid)
                    put("devicePreset", p.devicePreset)
                    put("networkMode", p.networkMode)
                    put("createdAt", p.createdAt)
                    put("lastUsedAt", p.lastUsedAt)
                }
            )
        }
        temp.writeText(array.toString())
        if (!temp.renameTo(file)) {
            file.writeText(array.toString())
            temp.delete()
        }
    }
}
