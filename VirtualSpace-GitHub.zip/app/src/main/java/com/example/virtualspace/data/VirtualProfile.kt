package com.example.virtualspace.data

import java.util.UUID

data class VirtualProfile(
    val id: String = UUID.randomUUID().toString(),
    val packageName: String,
    val label: String,
    val virtualRootEnabled: Boolean = false,
    val virtualUid: Int = 0,
    val virtualGid: Int = 0,
    val devicePreset: String = "DEFAULT",
    val networkMode: String = "HOST",
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsedAt: Long = 0L
)
