package com.example.virtualspace

import android.app.Application
import com.example.virtualspace.data.ProfileRepository

class VirtualSpaceApplication : Application() {
    val profileRepository by lazy { ProfileRepository(this) }
}
